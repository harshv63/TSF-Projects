# Basic-Banking-System
Sparks Foundation Web Development Internship Project : Basic Banking System website. A web application used to transfer virtual money between multiple users and also record the banking transactions/ activities.

Stack used: Front-end : HTML, CSS, Bootstrap, Javascript Back-end : PHP Database : MySQL

Database contains two Tables - Users Table & Transaction Table

User table have basic fields such as id, name,gender, email & current balance. Transaction table records all transfers happened along with their time.
